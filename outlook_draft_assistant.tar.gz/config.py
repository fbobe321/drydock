"""Configuration constants for Outlook Draft Assistant."""

import os
from dotenv import load_dotenv

load_dotenv()

# Local LLM configuration
LLM_ENDPOINT = os.getenv("LLM_ENDPOINT", "http://192.168.50.21:8000/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "default")
