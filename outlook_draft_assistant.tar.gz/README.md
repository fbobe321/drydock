# Outlook Local Draft Assistant

A Python CLI tool that generates draft email replies using a local LLM with GraphRAG-enhanced context. All processing happens locally - no email data is sent to external services.

## Features

- **Local LLM Integration**: Uses any OpenAI-compatible local endpoint
- **GraphRAG Context**: Searches 10K+ indexed emails for relevant history
- **Auto-indexing**: New emails automatically added to knowledge base
- **Outlook Integration**: Direct COM automation, no Azure setup required
- **Privacy-First**: Zero email data leaves your machine

## Requirements

- Windows with Microsoft Outlook installed
- Python 3.10+
- Local LLM server (OpenAI-compatible API)

## Installation

```bash
# Clone/download the project
cd email_test

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your LLM endpoint
```

## Quick Start

```bash
# 1. Build the GraphRAG index (one-time, ~10 min for 10K emails)
python main.py --build-index --index-all --max-emails 10000

# 2. Process emails and create drafts
python main.py --start-date 2024-04-29 --end-date 2024-04-30

# 3. Check your Outlook Drafts folder
```

## CLI Reference

### Process Emails

```bash
# Basic usage - process unread emails in date range
python main.py --start-date YYYY-MM-DD --end-date YYYY-MM-DD

# Options:
#   --dry-run          Generate drafts but don't save to Outlook
#   --max-emails N     Limit number of emails to process (default: 50)
#   --output-local F   Save results to file (JSON or Markdown)
#   --verbose          Show RAG context used for each email
#   --no-rag           Disable GraphRAG context retrieval
```

### GraphRAG Index

```bash
# Build index from inbox
python main.py --build-index --index-all --max-emails 10000

# Build from sent folder (for response style)
python main.py --build-index --folder sent --max-emails 5000

# Build from both folders
python main.py --build-index --folder both --max-emails 20000

# Check index statistics
python main.py --rag-stats
```

### Examples

```bash
# Process last week's emails with verbose output
python main.py --start-date 2024-05-01 --end-date 2024-05-07 --verbose

# Dry run on a single day, export to markdown
python main.py --start-date 2024-04-29 --end-date 2024-04-29 --dry-run --output-local review.md

# Process without RAG context
python main.py --start-date 2024-04-29 --end-date 2024-04-29 --no-rag
```

## Configuration

### Environment Variables (`.env`)

```bash
# Local LLM endpoint (OpenAI-compatible)
LLM_ENDPOINT=http://192.168.50.21:8000/v1

# Model name (if required by your endpoint)
LLM_MODEL=default
```

### Data Storage

- **GraphRAG Index**: `~/.outlook_draft_assistant/`
  - `chromadb/` - Vector store
  - `email_graph.pkl` - Relationship graph

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Outlook COM    │────▶│   GraphRAG      │────▶│   Local LLM     │
│  (email_client) │     │   (graph_rag)   │     │   (llm_client)  │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
   Fetch unread          Find similar            Generate draft
   Mark as read          emails + sender         with context
   Save drafts           history
```

## Module Usage

### Programmatic Access

```python
from email_client import EmailClient
from llm_client import LLMClient
from graph_rag import EmailGraphRAG
from datetime import datetime

# Initialize
email_client = EmailClient()
llm = LLMClient()
llm.enable_graph_rag()

# Fetch emails
emails = email_client.fetch_unread_emails(
    start_date=datetime(2024, 4, 29),
    end_date=datetime(2024, 4, 29),
)

# Process each email
for email in emails:
    draft = llm.generate_draft(
        sender=email["sender"],
        subject=email["subject"],
        body=email["body"],
    )
    email_client.create_draft_reply(email, draft)
```

### GraphRAG Direct Access

```python
from graph_rag import EmailGraphRAG, build_index_from_outlook

# Build index
build_index_from_outlook(max_emails=10000, include_read=True)

# Query index
rag = EmailGraphRAG()
context = rag.retrieve_context(
    sender="someone@example.com",
    subject="Meeting request",
    body="Can we meet tomorrow?"
)
print(context)

# Get stats
stats = rag.get_stats()
print(f"Indexed: {stats['emails_indexed']} emails")
```

## Security

- **No Send Capability**: The tool cannot send emails
- **Local Processing**: All LLM inference happens on your local server
- **Prompt Injection Protection**: Email content is sanitized before processing
- **No Cloud Dependencies**: Works entirely offline (except LLM server on local network)

## Troubleshooting

### "Cannot connect to Outlook"
- Ensure Outlook is running
- Run as the same user that owns the Outlook profile

### "Cannot connect to LLM"
- Check that your local LLM server is running
- Verify the endpoint in `.env`

### "No unread emails found"
- The date filter accounts for timezone differences
- Previously processed emails are marked as read

## License

MIT
