#!/usr/bin/env python3
"""CLI entry point for Outlook Local Draft Assistant."""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from email_client import EmailClient
from llm_client import LLMClient, LLMError
from config import LLM_ENDPOINT


def parse_date(date_str: str) -> datetime:
    """Parse a YYYY-MM-DD date string."""
    try:
        return datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid date format: '{date_str}'. Use YYYY-MM-DD."
        )


def create_parser() -> argparse.ArgumentParser:
    """Create and configure argument parser."""
    parser = argparse.ArgumentParser(
        description="Fetch unread Outlook emails and generate draft replies using a local LLM.",
    )

    parser.add_argument(
        "--start-date",
        type=parse_date,
        help="Start date for email search (YYYY-MM-DD)",
    )

    parser.add_argument(
        "--end-date",
        type=parse_date,
        help="End date for email search (YYYY-MM-DD)",
    )

    parser.add_argument(
        "--output-local",
        type=str,
        metavar="FILE",
        help="Save results to local file (JSON or Markdown based on extension)",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Generate drafts but don't save to Outlook",
    )

    parser.add_argument(
        "--max-emails",
        type=int,
        default=50,
        help="Maximum number of emails to process (default: 50)",
    )

    parser.add_argument(
        "--build-index",
        action="store_true",
        help="Build/update GraphRAG index from email history",
    )

    parser.add_argument(
        "--index-all",
        action="store_true",
        help="Include read emails when building index (more context)",
    )

    parser.add_argument(
        "--folder",
        type=str,
        choices=["inbox", "sent", "both"],
        default="inbox",
        help="Which folder to index: inbox, sent, or both (default: inbox)",
    )

    parser.add_argument(
        "--no-rag",
        action="store_true",
        help="Disable GraphRAG context retrieval",
    )

    parser.add_argument(
        "--rag-stats",
        action="store_true",
        help="Show GraphRAG index statistics",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show RAG context being used for each email",
    )

    return parser


def save_results_json(results: list, filepath: str):
    """Save results to JSON file."""
    output = [{k: v for k, v in r.items() if k != "_msg"} for r in results]
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)


def save_results_markdown(results: list, filepath: str):
    """Save results to Markdown file."""
    with open(filepath, "w", encoding="utf-8") as f:
        f.write("# Draft Replies Generated\n\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n\n")

        for i, result in enumerate(results, 1):
            f.write(f"## {i}. {result['subject']}\n\n")
            f.write(f"**From:** {result['sender']}\n\n")
            f.write(f"**Received:** {result['received_at']}\n\n")
            f.write("### Draft Reply\n\n")
            f.write(f"{result['draft']}\n\n")
            f.write("---\n\n")


def main():
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()

    # Handle --rag-stats
    if args.rag_stats:
        from graph_rag import EmailGraphRAG
        rag = EmailGraphRAG()
        stats = rag.get_stats()
        print("GraphRAG Index Statistics:")
        print(f"  Emails indexed:  {stats['emails_indexed']}")
        print(f"  Unique senders:  {stats['unique_senders']}")
        print(f"  Graph nodes:     {stats['graph_nodes']}")
        print(f"  Graph edges:     {stats['graph_edges']}")
        sys.exit(0)

    # Handle --build-index
    if args.build_index:
        from graph_rag import build_index_from_outlook
        build_index_from_outlook(
            start_date=args.start_date,
            end_date=args.end_date,
            include_read=args.index_all,
            max_emails=args.max_emails or 1000,
            folder=args.folder,
        )
        sys.exit(0)

    # Normal operation requires dates
    if not args.start_date or not args.end_date:
        print("Error: --start-date and --end-date required", file=sys.stderr)
        print("Use --build-index to build the GraphRAG index first", file=sys.stderr)
        sys.exit(1)

    if args.start_date > args.end_date:
        print("Error: Start date must be before or equal to end date.", file=sys.stderr)
        sys.exit(1)

    print(f"Initializing...")
    print(f"  LLM endpoint: {LLM_ENDPOINT}")

    llm = LLMClient()

    print("  Testing LLM connection...", end=" ", flush=True)
    if llm.test_connection():
        print("OK")
    else:
        print("FAILED")
        print(f"\nError: Cannot connect to LLM at {LLM_ENDPOINT}", file=sys.stderr)
        sys.exit(1)

    # Enable GraphRAG unless disabled
    if not args.no_rag:
        llm.enable_graph_rag()

    print("  Connecting to Outlook...", end=" ", flush=True)
    try:
        email_client = EmailClient()
        print("OK")
    except Exception as e:
        print("FAILED")
        print(f"\nError: Cannot connect to Outlook: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"\nFetching unread emails from {args.start_date.date()} to {args.end_date.date()}...")

    emails = email_client.fetch_unread_emails(
        start_date=args.start_date,
        end_date=args.end_date,
        max_results=args.max_emails,
    )

    if not emails:
        print("No unread emails found in the specified date range.")
        sys.exit(0)

    print(f"Found {len(emails)} unread email(s).\n")

    results = []
    success_count = 0
    error_count = 0

    # Get GraphRAG for auto-indexing new emails
    graph_rag = None
    if not args.no_rag and llm.graph_rag:
        graph_rag = llm.graph_rag

    for i, email in enumerate(emails, 1):
        subject_preview = email['subject'][:50] + "..." if len(email['subject']) > 50 else email['subject']
        subject_preview = subject_preview.encode('ascii', 'replace').decode('ascii')
        print(f"[{i}/{len(emails)}] {subject_preview}")

        # Auto-index new emails into GraphRAG
        if graph_rag:
            try:
                graph_rag.index_email(email)
            except Exception:
                pass  # Silently skip indexing errors

        # Show RAG context if verbose
        if args.verbose and graph_rag:
            context = graph_rag.retrieve_context(
                email["sender"], email["subject"], email["body"]
            )
            if context:
                print(f"  [RAG Context]\n{context[:500]}...")
            else:
                print(f"  [RAG Context] No relevant history found")

        try:
            draft_text = llm.generate_draft(
                sender=email["sender"],
                subject=email["subject"],
                body=email["body"],
            )
        except LLMError as e:
            print(f"  Error generating draft: {e}")
            error_count += 1
            continue

        email["draft"] = draft_text

        if not args.dry_run:
            try:
                email_client.create_draft_reply(email, draft_text)
                print(f"  Draft saved to Outlook")
            except Exception as e:
                print(f"  Error saving draft: {e}")
                error_count += 1
                continue
        else:
            print(f"  Draft generated (dry-run)")

        results.append(email)
        success_count += 1

    if args.output_local and results:
        output_path = Path(args.output_local)
        if output_path.suffix.lower() == ".md":
            save_results_markdown(results, args.output_local)
        else:
            save_results_json(results, args.output_local)
        print(f"\nResults saved to: {args.output_local}")

    print(f"\n{'='*40}")
    print(f"Done: {success_count} drafts created, {error_count} errors")

    if not args.dry_run and success_count > 0:
        print("Check your Outlook Drafts folder.")


if __name__ == "__main__":
    main()
