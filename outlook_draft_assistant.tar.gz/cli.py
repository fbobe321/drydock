#!/usr/bin/env python3
"""
CLI module for Outlook Local Draft Assistant.

This module provides a clean interface for external harnesses to invoke
the draft assistant programmatically or via command-line.
"""

import sys
from datetime import datetime
from typing import Optional, Callable

from email_client import EmailClient
from llm_client import LLMClient, LLMError
from graph_rag import EmailGraphRAG, build_index_from_outlook
from config import LLM_ENDPOINT


class DraftAssistant:
    """
    Main interface for the Outlook Draft Assistant.

    Example usage:
        assistant = DraftAssistant()
        assistant.initialize()
        results = assistant.process_emails(
            start_date=datetime(2024, 4, 29),
            end_date=datetime(2024, 4, 29),
        )
    """

    def __init__(
        self,
        llm_endpoint: str = None,
        use_rag: bool = True,
        verbose: bool = False,
        on_progress: Callable[[str], None] = None,
    ):
        """
        Initialize the Draft Assistant.

        Args:
            llm_endpoint: Override LLM endpoint URL
            use_rag: Enable GraphRAG context retrieval
            verbose: Print detailed progress
            on_progress: Callback for progress updates
        """
        self.llm_endpoint = llm_endpoint or LLM_ENDPOINT
        self.use_rag = use_rag
        self.verbose = verbose
        self.on_progress = on_progress or (lambda x: None)

        self.email_client: Optional[EmailClient] = None
        self.llm: Optional[LLMClient] = None
        self.graph_rag: Optional[EmailGraphRAG] = None

    def _log(self, message: str):
        """Log a progress message."""
        self.on_progress(message)
        if self.verbose:
            print(message)

    def initialize(self) -> bool:
        """
        Initialize connections to Outlook and LLM.

        Returns:
            True if initialization successful, False otherwise
        """
        # Initialize LLM
        self._log("Connecting to LLM...")
        self.llm = LLMClient(endpoint=self.llm_endpoint)

        if not self.llm.test_connection():
            self._log(f"ERROR: Cannot connect to LLM at {self.llm_endpoint}")
            return False

        # Enable GraphRAG
        if self.use_rag:
            self._log("Loading GraphRAG index...")
            if self.llm.enable_graph_rag():
                self.graph_rag = self.llm.graph_rag

        # Initialize Outlook
        self._log("Connecting to Outlook...")
        try:
            self.email_client = EmailClient()
        except Exception as e:
            self._log(f"ERROR: Cannot connect to Outlook: {e}")
            return False

        return True

    def process_emails(
        self,
        start_date: datetime,
        end_date: datetime,
        max_emails: int = 50,
        dry_run: bool = False,
    ) -> list[dict]:
        """
        Process unread emails and generate drafts.

        Args:
            start_date: Start of date range
            end_date: End of date range
            max_emails: Maximum emails to process
            dry_run: If True, don't save drafts to Outlook

        Returns:
            List of result dictionaries with email info and generated drafts
        """
        if not self.email_client or not self.llm:
            raise RuntimeError("Must call initialize() first")

        # Fetch emails
        self._log(f"Fetching unread emails from {start_date.date()} to {end_date.date()}...")
        emails = self.email_client.fetch_unread_emails(
            start_date=start_date,
            end_date=end_date,
            max_results=max_emails,
        )

        if not emails:
            self._log("No unread emails found")
            return []

        self._log(f"Found {len(emails)} unread email(s)")

        results = []
        for i, email in enumerate(emails, 1):
            subject_preview = email['subject'][:50]
            self._log(f"[{i}/{len(emails)}] {subject_preview}")

            # Auto-index into GraphRAG
            if self.graph_rag:
                try:
                    self.graph_rag.index_email(email)
                except Exception:
                    pass

            # Generate draft
            try:
                draft_text = self.llm.generate_draft(
                    sender=email["sender"],
                    subject=email["subject"],
                    body=email["body"],
                )
            except LLMError as e:
                self._log(f"  Error: {e}")
                continue

            result = {
                "email_id": email["id"],
                "subject": email["subject"],
                "sender": email["sender"],
                "received_at": email["received_at"],
                "draft": draft_text,
                "draft_saved": False,
            }

            # Save draft to Outlook
            if not dry_run:
                try:
                    self.email_client.create_draft_reply(email, draft_text)
                    result["draft_saved"] = True
                    self._log("  Draft saved")
                except Exception as e:
                    self._log(f"  Error saving: {e}")
            else:
                self._log("  Draft generated (dry-run)")

            results.append(result)

        return results

    def build_index(
        self,
        max_emails: int = 10000,
        include_read: bool = True,
        folder: str = "inbox",
    ) -> dict:
        """
        Build or update the GraphRAG index.

        Args:
            max_emails: Maximum emails to index
            include_read: Include read emails
            folder: "inbox", "sent", or "both"

        Returns:
            Index statistics dictionary
        """
        self._log(f"Building index from {folder}...")
        rag = build_index_from_outlook(
            include_read=include_read,
            max_emails=max_emails,
            folder=folder,
        )
        return rag.get_stats()

    def get_rag_stats(self) -> dict:
        """Get GraphRAG index statistics."""
        rag = EmailGraphRAG()
        return rag.get_stats()


# Convenience functions for simple scripting

def process(
    start_date: str,
    end_date: str,
    dry_run: bool = False,
    max_emails: int = 50,
    verbose: bool = True,
) -> list[dict]:
    """
    Simple function to process emails.

    Args:
        start_date: Start date as "YYYY-MM-DD"
        end_date: End date as "YYYY-MM-DD"
        dry_run: Don't save drafts if True
        max_emails: Maximum emails to process
        verbose: Print progress

    Returns:
        List of results

    Example:
        from cli import process
        results = process("2024-04-29", "2024-04-29", dry_run=True)
    """
    assistant = DraftAssistant(verbose=verbose)

    if not assistant.initialize():
        return []

    return assistant.process_emails(
        start_date=datetime.strptime(start_date, "%Y-%m-%d"),
        end_date=datetime.strptime(end_date, "%Y-%m-%d"),
        max_emails=max_emails,
        dry_run=dry_run,
    )


def build_index(max_emails: int = 10000, folder: str = "inbox") -> dict:
    """
    Build the GraphRAG index.

    Args:
        max_emails: Maximum emails to index
        folder: "inbox", "sent", or "both"

    Returns:
        Index statistics

    Example:
        from cli import build_index
        stats = build_index(max_emails=10000)
        print(f"Indexed {stats['emails_indexed']} emails")
    """
    return build_index_from_outlook(
        include_read=True,
        max_emails=max_emails,
        folder=folder,
    ).get_stats()


def stats() -> dict:
    """
    Get GraphRAG index statistics.

    Returns:
        Statistics dictionary

    Example:
        from cli import stats
        print(stats())
    """
    return EmailGraphRAG().get_stats()


if __name__ == "__main__":
    # If run directly, defer to main.py
    import main
    main.main()
