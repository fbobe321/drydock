"""GraphRAG system for email context retrieval."""

import os
import json
import pickle
import re
from datetime import datetime
from pathlib import Path

import chromadb
from chromadb.config import Settings
import networkx as nx

from config import LLM_ENDPOINT


# Storage paths
DATA_DIR = Path.home() / ".outlook_draft_assistant"
GRAPH_PATH = DATA_DIR / "email_graph.pkl"
CHROMA_PATH = DATA_DIR / "chromadb"


class EmailGraphRAG:
    """GraphRAG system for email retrieval and context."""

    def __init__(self):
        DATA_DIR.mkdir(exist_ok=True)

        # Initialize ChromaDB for vector search
        self.chroma = chromadb.PersistentClient(
            path=str(CHROMA_PATH),
            settings=Settings(anonymized_telemetry=False),
        )
        self.collection = self.chroma.get_or_create_collection(
            name="emails",
            metadata={"hnsw:space": "cosine"},
        )

        # Initialize NetworkX graph for relationships
        self.graph = self._load_graph()

    def _load_graph(self) -> nx.DiGraph:
        """Load graph from disk or create new one."""
        if GRAPH_PATH.exists():
            with open(GRAPH_PATH, "rb") as f:
                return pickle.load(f)
        return nx.DiGraph()

    def _save_graph(self):
        """Save graph to disk."""
        with open(GRAPH_PATH, "wb") as f:
            pickle.dump(self.graph, f)

    def _extract_email_domain(self, email: str) -> str:
        """Extract domain from email address."""
        match = re.search(r"@([\w.-]+)", email)
        return match.group(1) if match else ""

    def _extract_keywords(self, text: str) -> list[str]:
        """Extract simple keywords from text."""
        # Remove common words and extract meaningful terms
        stop_words = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to",
            "for", "of", "with", "by", "from", "is", "are", "was", "were",
            "be", "been", "being", "have", "has", "had", "do", "does", "did",
            "will", "would", "could", "should", "may", "might", "can", "this",
            "that", "these", "those", "i", "you", "he", "she", "it", "we", "they",
            "my", "your", "his", "her", "its", "our", "their", "me", "him",
        }
        words = re.findall(r"\b[a-zA-Z]{3,}\b", text.lower())
        return list(set(w for w in words if w not in stop_words))[:20]

    def index_email(self, email: dict):
        """
        Index an email into the GraphRAG system.

        Args:
            email: Email dict with id, sender, subject, body, received_at
        """
        email_id = email["id"]
        sender = email.get("sender", "unknown")
        sender_name = email.get("sender_name", "")
        subject = email.get("subject", "")
        body = email.get("body", "")
        received_at = email.get("received_at", "")

        # Create document text for embedding
        doc_text = f"From: {sender_name} <{sender}>\nSubject: {subject}\n\n{body[:2000]}"

        # Check if already indexed
        existing = self.collection.get(ids=[email_id])
        if existing["ids"]:
            return  # Already indexed

        # Add to ChromaDB vector store
        self.collection.add(
            ids=[email_id],
            documents=[doc_text],
            metadatas=[{
                "sender": sender,
                "sender_name": sender_name,
                "subject": subject,
                "received_at": received_at,
                "domain": self._extract_email_domain(sender),
            }],
        )

        # Add to graph
        # Node for this email
        self.graph.add_node(
            email_id,
            type="email",
            subject=subject,
            received_at=received_at,
        )

        # Node for sender
        sender_node = f"sender:{sender}"
        if not self.graph.has_node(sender_node):
            self.graph.add_node(
                sender_node,
                type="sender",
                email=sender,
                name=sender_name,
            )
        self.graph.add_edge(sender_node, email_id, relation="sent")

        # Node for domain
        domain = self._extract_email_domain(sender)
        if domain:
            domain_node = f"domain:{domain}"
            if not self.graph.has_node(domain_node):
                self.graph.add_node(domain_node, type="domain", domain=domain)
            self.graph.add_edge(domain_node, sender_node, relation="contains")

        # Add keyword nodes
        keywords = self._extract_keywords(subject + " " + body[:500])
        for kw in keywords[:10]:
            kw_node = f"keyword:{kw}"
            if not self.graph.has_node(kw_node):
                self.graph.add_node(kw_node, type="keyword", keyword=kw)
            self.graph.add_edge(email_id, kw_node, relation="about")

        self._save_graph()

    def index_emails_batch(self, emails: list[dict]):
        """Index multiple emails."""
        for email in emails:
            self.index_email(email)
        print(f"Indexed {len(emails)} emails into GraphRAG")

    def retrieve_context(
        self,
        sender: str,
        subject: str,
        body: str,
        n_results: int = 5,
    ) -> str:
        """
        Retrieve relevant context for drafting a reply.

        Args:
            sender: Email sender
            subject: Email subject
            body: Email body
            n_results: Number of similar emails to retrieve

        Returns:
            Formatted context string with relevant past emails
        """
        if self.collection.count() == 0:
            return ""

        # Query vector store for similar emails
        query_text = f"From: {sender}\nSubject: {subject}\n\n{body[:1000]}"

        results = self.collection.query(
            query_texts=[query_text],
            n_results=min(n_results, self.collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        if not results["ids"][0]:
            return ""

        # Also get graph-based context (emails from same sender)
        sender_emails = self._get_sender_history(sender, limit=3)

        # Format context
        context_parts = []

        # Add vector search results
        for i, (doc, meta, dist) in enumerate(zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        )):
            if dist > 1.5:  # Skip if too dissimilar
                continue
            context_parts.append(
                f"[Similar Email {i+1}]\n"
                f"From: {meta.get('sender_name', '')} <{meta.get('sender', '')}>\n"
                f"Subject: {meta.get('subject', '')}\n"
                f"Date: {meta.get('received_at', '')}\n"
                f"---\n{doc[:500]}..."
            )

        # Add sender history if not already included
        for email_id, data in sender_emails:
            if email_id not in results["ids"][0]:
                context_parts.append(
                    f"[Previous from this sender]\n"
                    f"Subject: {data.get('subject', '')}\n"
                    f"Date: {data.get('received_at', '')}"
                )

        if not context_parts:
            return ""

        return (
            "\n\n=== RELEVANT CONTEXT FROM EMAIL HISTORY ===\n\n"
            + "\n\n".join(context_parts[:5])
            + "\n\n=== END CONTEXT ===\n"
        )

    def _get_sender_history(self, sender: str, limit: int = 3) -> list:
        """Get previous emails from the same sender."""
        sender_node = f"sender:{sender}"
        if not self.graph.has_node(sender_node):
            return []

        emails = []
        for _, target, data in self.graph.out_edges(sender_node, data=True):
            if data.get("relation") == "sent":
                node_data = self.graph.nodes[target]
                if node_data.get("type") == "email":
                    emails.append((target, node_data))

        # Sort by date descending
        emails.sort(key=lambda x: x[1].get("received_at", ""), reverse=True)
        return emails[:limit]

    def get_stats(self) -> dict:
        """Get statistics about the indexed data."""
        email_count = sum(
            1 for _, d in self.graph.nodes(data=True)
            if d.get("type") == "email"
        )
        sender_count = sum(
            1 for _, d in self.graph.nodes(data=True)
            if d.get("type") == "sender"
        )
        return {
            "emails_indexed": self.collection.count(),
            "graph_emails": email_count,
            "unique_senders": sender_count,
            "graph_nodes": self.graph.number_of_nodes(),
            "graph_edges": self.graph.number_of_edges(),
        }


def build_index_from_outlook(
    start_date: datetime = None,
    end_date: datetime = None,
    include_read: bool = True,
    max_emails: int = 1000,
    folder: str = "inbox",
):
    """
    Build GraphRAG index from Outlook emails.

    Args:
        start_date: Start of date range
        end_date: End of date range
        include_read: Include read emails (for historical context)
        max_emails: Maximum emails to index
        folder: Which folder to index - "inbox", "sent", or "both"
    """
    import win32com.client

    outlook = win32com.client.Dispatch("Outlook.Application")
    namespace = outlook.GetNamespace("MAPI")

    # Folder constants: 6 = Inbox, 5 = Sent Items
    folders_to_index = []
    if folder in ("inbox", "both"):
        folders_to_index.append(("Inbox", namespace.GetDefaultFolder(6)))
    if folder in ("sent", "both"):
        folders_to_index.append(("Sent Items", namespace.GetDefaultFolder(5)))

    graph_rag = EmailGraphRAG()
    total_indexed = 0

    for folder_name, folder_obj in folders_to_index:
        print(f"\nIndexing {folder_name}...")
        messages = folder_obj.Items
        messages.Sort("[ReceivedTime]", True)

        # Build filter
        filters = []
        if not include_read and folder_name == "Inbox":
            filters.append("[Unread] = True")
        if start_date:
            filters.append(f"[ReceivedTime] >= '{start_date.strftime('%m/%d/%Y')}'")
        if end_date:
            filters.append(f"[ReceivedTime] <= '{end_date.strftime('%m/%d/%Y 11:59 PM')}'")

        if filters:
            filter_str = " AND ".join(filters)
            messages = messages.Restrict(filter_str)

        folder_indexed = 0
        emails_per_folder = max_emails if folder != "both" else max_emails // 2

        for msg in messages:
            if folder_indexed >= emails_per_folder:
                break
            try:
                # For sent items, we are the sender
                if folder_name == "Sent Items":
                    email = {
                        "id": msg.EntryID,
                        "subject": msg.Subject or "(No Subject)",
                        "sender": "me",
                        "sender_name": "My Response",
                        "body": msg.Body or "",
                        "received_at": msg.SentOn.strftime("%Y-%m-%d %H:%M:%S") if msg.SentOn else "",
                        "is_sent": True,
                    }
                else:
                    email = {
                        "id": msg.EntryID,
                        "subject": msg.Subject or "(No Subject)",
                        "sender": msg.SenderEmailAddress or "unknown",
                        "sender_name": msg.SenderName or "",
                        "body": msg.Body or "",
                        "received_at": msg.ReceivedTime.strftime("%Y-%m-%d %H:%M:%S"),
                        "is_sent": False,
                    }
                graph_rag.index_email(email)
                folder_indexed += 1
                total_indexed += 1
                if folder_indexed % 100 == 0:
                    print(f"  {folder_name}: {folder_indexed} emails indexed...")
            except Exception:
                continue

        print(f"  {folder_name}: {folder_indexed} emails indexed")

    stats = graph_rag.get_stats()
    print(f"\nIndexing complete!")
    print(f"  Total emails in vector store: {stats['emails_indexed']}")
    print(f"  Unique senders: {stats['unique_senders']}")
    print(f"  Graph nodes: {stats['graph_nodes']}")
    print(f"  Graph edges: {stats['graph_edges']}")

    return graph_rag
