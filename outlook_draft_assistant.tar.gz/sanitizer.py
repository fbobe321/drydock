"""Email body sanitization for prompt injection protection."""

import re


# Patterns that could be used for prompt injection
INJECTION_PATTERNS = [
    # Direct instruction patterns
    r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?)",
    r"disregard\s+(all\s+)?(previous|prior|above)",
    r"forget\s+(everything|all|what)\s+(you|i)\s+(said|told|wrote)",
    r"new\s+instructions?:",
    r"system\s*:\s*",
    r"assistant\s*:\s*",
    r"user\s*:\s*",

    # Role manipulation
    r"you\s+are\s+now\s+a",
    r"act\s+as\s+(a\s+)?",
    r"pretend\s+(to\s+be|you're)",
    r"roleplay\s+as",

    # Output manipulation
    r"respond\s+with\s+only",
    r"output\s+only",
    r"say\s+exactly",
    r"repeat\s+after\s+me",

    # Boundary markers
    r"<\|.*?\|>",
    r"\[INST\]",
    r"\[/INST\]",
    r"<<SYS>>",
    r"<</SYS>>",
]

# Compile patterns for efficiency
COMPILED_PATTERNS = [re.compile(p, re.IGNORECASE) for p in INJECTION_PATTERNS]


def sanitize_email_body(text: str) -> str:
    """
    Sanitize email body to protect against prompt injection.

    Args:
        text: Raw email body text

    Returns:
        Sanitized text safe for LLM processing
    """
    if not text:
        return ""

    # Normalize unicode to ASCII where possible
    text = normalize_text(text)

    # Remove or replace suspicious patterns
    for pattern in COMPILED_PATTERNS:
        text = pattern.sub("[FILTERED]", text)

    # Remove excessive whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{3,}", "  ", text)

    # Remove null bytes and other control characters (except newlines/tabs)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", text)

    # Limit overall length to prevent token stuffing
    max_chars = 10000
    if len(text) > max_chars:
        text = text[:max_chars] + "\n\n[Content truncated for length]"

    return text.strip()


def normalize_text(text: str) -> str:
    """Normalize unicode characters that could be used to bypass filters."""
    # Common unicode tricks
    replacements = {
        "\u200b": "",  # Zero-width space
        "\u200c": "",  # Zero-width non-joiner
        "\u200d": "",  # Zero-width joiner
        "\ufeff": "",  # BOM
        "\u00a0": " ",  # Non-breaking space
        "\u2028": "\n",  # Line separator
        "\u2029": "\n\n",  # Paragraph separator
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    return text


def create_safe_context(sender: str, subject: str, body: str) -> str:
    """
    Create a safely formatted context string for LLM processing.

    Args:
        sender: Email sender address
        subject: Email subject line
        body: Sanitized email body

    Returns:
        Formatted context string
    """
    # Sanitize all fields
    safe_sender = re.sub(r"[<>]", "", sender)[:100]
    safe_subject = sanitize_email_body(subject)[:200]
    safe_body = sanitize_email_body(body)

    return f"""---EMAIL START---
From: {safe_sender}
Subject: {safe_subject}

{safe_body}
---EMAIL END---"""
