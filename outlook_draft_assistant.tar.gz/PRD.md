# Product Requirements Document (PRD): Outlook Local Draft Assistant

## 1. Executive Summary
**Objective:** A Python CLI tool that scans a local Outlook inbox for unread emails within a user-specified date range, generates context-aware draft replies using a local LLM with GraphRAG-enhanced context, and saves them as Outlook drafts.

**Strict Constraint:** The system is strictly read/draft-only. It cannot send emails, ensuring the user retains absolute approval authority over all outgoing communication.

## 2. Target Audience & Use Case
Designed for technical professionals managing high-volume inboxes who require automated triage and drafting, while maintaining strict data sovereignty. The tool prevents sensitive email data from being transmitted to third-party cloud APIs by leveraging local infrastructure for natural language processing.

## 3. Core Features & Requirements

### 3.1. Email Fetching & Filtering
* **Connection:** Direct COM automation with local Outlook application (no Azure/cloud setup required)
* **Query Parameters:**
  * `is_read == False`
  * `date_received >= [Start_Date]` AND `date_received <= [End_Date]`
* **Data Extraction:** Parse sender, subject, date, and raw body text
* **Auto-marking:** Emails are marked as read after draft creation

### 3.2. GraphRAG Context System (Implemented)
* **Vector Store:** ChromaDB with sentence-transformer embeddings for semantic search
* **Graph Database:** NetworkX for relationship tracking (senders, domains, keywords)
* **Index Capacity:** Tested with 10,000+ emails, scalable to 50,000+
* **Auto-indexing:** New emails automatically added to index during processing
* **Context Retrieval:** Finds similar past emails and sender history for each draft

### 3.3. Draft Generation (Local Inference)
* **LLM Integration:** OpenAI-compatible local endpoint (default: `http://192.168.50.21:8000/v1`)
* **RAG-Enhanced Prompting:** Includes relevant email history context for better drafts
* **Safety & Sanitization:** Pre-processing to sanitize incoming email bodies against prompt injection
* **Validation:** Retry logic for empty responses with fallback defaults

### 3.4. Review Mechanism
* **Draft Storage:** Push generated responses to Outlook Drafts folder, threaded to original
* **Local Review:** Optional JSON/Markdown export for terminal-based review
* **Verbose Mode:** `--verbose` flag shows RAG context used for each draft

## 4. Technical Architecture

### 4.1. Tech Stack
* **Language:** Python 3.10+
* **Email Access:** `pywin32` COM automation (Windows/Outlook)
* **Vector Store:** `chromadb` with `sentence-transformers`
* **Graph Store:** `networkx`
* **Inference Client:** `openai` Python package pointing to local LLM
* **Configuration:** `python-dotenv` for environment management

### 4.2. Project Structure
```
email_test/
├── main.py             # CLI entry point with argparse
├── config.py           # Configuration (LLM endpoint, etc.)
├── email_client.py     # Outlook COM operations
├── llm_client.py       # OpenAI-compatible LLM client with RAG
├── graph_rag.py        # GraphRAG indexing and retrieval
├── sanitizer.py        # Prompt injection protection
├── requirements.txt    # Dependencies
├── .env                # Environment variables
└── README.md           # Usage documentation
```

### 4.3. Execution Flow
1. **Init:** Parse CLI arguments, load configuration
2. **Connect:** Initialize Outlook COM connection and LLM client
3. **RAG Setup:** Load GraphRAG index (if available)
4. **Fetch:** Query Outlook for unread emails in date range
5. **Process Loop:**
   * Auto-index email into GraphRAG
   * Retrieve relevant context from email history
   * Sanitize email body
   * Generate draft via local LLM with RAG context
   * Save draft to Outlook, mark original as read
6. **Report:** Output summary of drafts created

## 5. Security & Privacy Constraints
* **Data Sovereignty:** All processing via local LLM - zero email data sent externally
* **No Send Capability:** Application physically cannot send emails
* **Prompt Injection Protection:** Input sanitization filters malicious patterns
* **Local Storage:** GraphRAG index stored in user home directory

## 6. CLI Commands

### Basic Operations
```bash
# Process unread emails and create drafts
python main.py --start-date 2024-04-29 --end-date 2024-04-30

# Dry run (generate but don't save)
python main.py --start-date 2024-04-29 --end-date 2024-04-30 --dry-run

# Export to local file
python main.py --start-date 2024-04-29 --end-date 2024-04-30 --output-local results.md
```

### GraphRAG Operations
```bash
# Build index from inbox
python main.py --build-index --index-all --max-emails 10000

# Build index from sent folder
python main.py --build-index --folder sent --max-emails 5000

# Build from both folders
python main.py --build-index --folder both --max-emails 20000

# View index statistics
python main.py --rag-stats
```

### Debug/Verbose
```bash
# Show RAG context being used
python main.py --start-date 2024-04-29 --end-date 2024-04-30 --verbose

# Disable RAG
python main.py --start-date 2024-04-29 --end-date 2024-04-30 --no-rag
```

## 7. Future Considerations (V2)
* Terminal UI (TUI) for rapid approve/reject/edit cycling
* Calendar integration for meeting-related email context
* Multi-account support
* Scheduled background processing
* Custom prompt templates per sender/domain
