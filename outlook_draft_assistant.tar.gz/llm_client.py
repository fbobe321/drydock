"""OpenAI-compatible local LLM client."""

from openai import OpenAI

from config import LLM_ENDPOINT, LLM_MODEL
from sanitizer import create_safe_context


SYSTEM_PROMPT = """You are a professional email assistant helping to draft replies to emails.

Your task is to generate a polite, professional, and helpful draft reply based on the email content provided.

Guidelines:
- Be professional and courteous
- Keep responses concise but complete
- Match the tone of the original email when appropriate
- If the email requires information you don't have, indicate what information is needed
- Do not make up specific facts, dates, or commitments
- Use appropriate greetings and sign-offs
- If the email is spam or doesn't require a response, say so briefly
- If context from previous emails is provided, use it to inform your response style and content

Respond with ONLY the draft email text, no explanations or meta-commentary."""


class LLMClient:
    """Client for OpenAI-compatible local LLM."""

    def __init__(self, endpoint: str = None, model: str = None):
        self.endpoint = endpoint or LLM_ENDPOINT
        self.model = model or LLM_MODEL
        self.graph_rag = None

        self.client = OpenAI(
            base_url=self.endpoint,
            api_key="not-needed",
        )

    def enable_graph_rag(self):
        """Enable GraphRAG context retrieval."""
        from graph_rag import EmailGraphRAG
        self.graph_rag = EmailGraphRAG()
        stats = self.graph_rag.get_stats()
        if stats["emails_indexed"] > 0:
            print(f"  GraphRAG enabled ({stats['emails_indexed']} emails indexed)")
            return True
        else:
            print(f"  GraphRAG: No emails indexed yet")
            return False

    def generate_draft(
        self,
        sender: str,
        subject: str,
        body: str,
        additional_context: str = "",
        use_rag: bool = True,
    ) -> str:
        """
        Generate a draft reply for an email.

        Args:
            sender: Email sender address
            subject: Email subject
            body: Email body (will be sanitized)
            additional_context: Optional additional instructions
            use_rag: Whether to use GraphRAG for context

        Returns:
            Generated draft reply text
        """
        # Create safely formatted context
        email_context = create_safe_context(sender, subject, body)

        # Get RAG context if available
        rag_context = ""
        if use_rag and self.graph_rag:
            try:
                rag_context = self.graph_rag.retrieve_context(sender, subject, body)
            except Exception:
                pass  # Silently skip RAG if it fails

        user_message = f"Please draft a reply to the following email:\n\n{email_context}"

        if rag_context:
            user_message += f"\n\n{rag_context}"

        if additional_context:
            user_message += f"\n\nAdditional context: {additional_context}"

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
                temperature=0.7,
                max_tokens=1000,
            )

            draft = response.choices[0].message.content.strip()

            # Validate we got actual content
            if not draft or len(draft) < 10:
                # Retry with more explicit prompt
                retry_message = (
                    f"Please write a brief, professional reply to this email.\n\n"
                    f"From: {sender}\n"
                    f"Subject: {subject}\n\n"
                    f"Even if this is a newsletter or automated email, write a one-line acknowledgment "
                    f"or state 'No response needed - automated/marketing email.'"
                )
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": retry_message},
                    ],
                    temperature=0.7,
                    max_tokens=500,
                )
                draft = response.choices[0].message.content.strip()

            # Final fallback
            if not draft or len(draft) < 5:
                draft = "No response needed - this appears to be an automated or informational email."

            return draft

        except Exception as e:
            raise LLMError(f"Failed to generate draft: {e}") from e

    def test_connection(self) -> bool:
        """Test if the LLM endpoint is reachable."""
        try:
            self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": "Hello"}],
                max_tokens=5,
            )
            return True
        except Exception:
            return False


class LLMError(Exception):
    """Exception raised for LLM-related errors."""
    pass
