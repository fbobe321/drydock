"""Local Outlook email operations via COM automation."""

import win32com.client
from datetime import datetime
from typing import Optional


class EmailClient:
    """Client for local Outlook operations via COM."""

    def __init__(self):
        self.outlook = win32com.client.Dispatch("Outlook.Application")
        self.namespace = self.outlook.GetNamespace("MAPI")

    def fetch_unread_emails(
        self,
        start_date: datetime,
        end_date: datetime,
        max_results: int = 100,
    ) -> list[dict]:
        """
        Fetch unread emails within a date range from local Outlook.

        Args:
            start_date: Start of date range (inclusive)
            end_date: End of date range (inclusive)
            max_results: Maximum number of emails to fetch

        Returns:
            List of email dictionaries
        """
        inbox = self.namespace.GetDefaultFolder(6)  # 6 = olFolderInbox
        messages = inbox.Items
        messages.Sort("[ReceivedTime]", True)  # Sort descending

        # Build filter - use day before/after to handle timezone issues
        from datetime import timedelta
        adjusted_start = start_date - timedelta(days=1)
        adjusted_end = end_date + timedelta(days=1)
        start_str = adjusted_start.strftime("%m/%d/%Y")
        end_str = adjusted_end.strftime("%m/%d/%Y 11:59 PM")
        filter_str = (
            f"[Unread] = True AND "
            f"[ReceivedTime] >= '{start_str}' AND "
            f"[ReceivedTime] <= '{end_str}'"
        )

        filtered = messages.Restrict(filter_str)
        emails = []

        for i, msg in enumerate(filtered):
            if i >= max_results:
                break
            try:
                emails.append({
                    "id": msg.EntryID,
                    "subject": msg.Subject or "(No Subject)",
                    "sender": msg.SenderEmailAddress or "unknown",
                    "sender_name": msg.SenderName or "",
                    "body": msg.Body or "",
                    "received_at": msg.ReceivedTime.strftime("%Y-%m-%d %H:%M:%S"),
                    "_msg": msg,  # Keep reference for reply
                })
            except Exception:
                continue

        return emails

    def create_draft_reply(
        self,
        email: dict,
        draft_body: str,
    ) -> dict:
        """
        Create a draft reply to an email and mark original as read.

        Args:
            email: Email dict from fetch_unread_emails (must have _msg)
            draft_body: The body text for the draft reply

        Returns:
            Dictionary with draft details
        """
        msg = email["_msg"]
        reply = msg.Reply()
        reply.Body = draft_body + "\n\n" + reply.Body
        reply.Save()  # Saves to Drafts folder

        # Mark original email as read
        msg.UnRead = False
        msg.Save()

        return {
            "id": reply.EntryID,
            "subject": reply.Subject,
        }
